//
//  ViewController.swift
//  ratingPOC
//
//  Created by Omar AlQasmi on 06/10/2021.
// refer to https://github.com/evgenyneu/Cosmos
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var vwStarRating: CosmosView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        vwStarRating.rating = 0
        vwStarRating.totalStars = 5
        vwStarRating.minTouchRating = 0
//        vwStarRating.text = "POC rate"
        
        // Use if you need just to show the stars without getting user's input
        vwStarRating.settings.updateOnTouch = true

        // Show only fully filled stars
        vwStarRating.settings.fillMode = .half
        // Other fill modes: .half, .precise

        // Change the size of the stars
        vwStarRating.settings.starSize = 45

        // Set the distance between stars
        vwStarRating.settings.starMargin = 5

        // Set the color of a filled star
        vwStarRating.settings.filledColor = UIColor.yellow

        // Set the border color of an empty star
        vwStarRating.settings.emptyBorderColor = UIColor.black
        vwStarRating.settings.emptyColor = UIColor.lightGray
        vwStarRating.settings.emptyBorderWidth = 1

        // Set the border color of a filled star
        vwStarRating.settings.filledBorderColor = UIColor.orange
        vwStarRating.settings.filledBorderWidth = 3

        vwStarRating.didTouchCosmos = didTouchStarRating
        vwStarRating.didFinishTouchingCosmos = didFinishTouchingStarRating

    }
    func didTouchStarRating (rating : Double){
        print("didTouchStarRating :: \(rating)")
    }
    func didFinishTouchingStarRating (rating : Double){
        print("didFinishTouchingStarRating :: \(rating)")
    }
}

